#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>

#define GPIO_LED_MAGIC  'L'

static const char *led_devs[] = { "/dev/green_led", "/dev/blue_led", "/dev/red_led" };
#define NLEDS (sizeof(led_devs) / sizeof(led_devs[0]))

int main(int argc, char *argv[])
{
        int idx, state;
        int fd;
        int ret;

        if (argc < 3) {
                printf("Usage: ./test_ioctl <led_idx> <0/1>\n");
                return -EINVAL;
        }

        /* Get led idx and state */
        idx = atoi(argv[1]);
        state = atoi(argv[2]) ? 1 : 0;

        if (idx + 1 > NLEDS) {
                printf("Please select and idx between 0 and %ld\n", NLEDS - 1);
                return -EINVAL;
        }

        fd = open(led_devs[idx], O_RDONLY);

        if (errno) {
                printf("Opening %s failed with err %d\n", led_devs[idx], errno);
                return errno;
        }

        /* Use ioctl to turn led on/off */
        ret = ioctl(fd, _IO(GPIO_LED_MAGIC, state), NULL);
        if (ret) {
                printf("IOCTL on %s failed with err %d\n", led_devs[idx], ret);
                return ret;
        }

        return 0;
}
